package queens.main;

public class Board {
	public int solutionCount=0;
	
	private int queens=0;	
	private boolean[][] board = new boolean[8][8];
	private int[] stack = new int[8];
	
	public int getQueens() {
		return queens;
	}

	public Board(){
		super();
	}
	
	public void incQueens(){
		if(this.queens>=0 && this.queens<=7){
			queens++;
		}
		if(this.queens==8){
			this.solutionCount++;	// Queens==8 => A solution has been found.
			this.printStack();			
		}
	}
	
	public void decQueens(){
		if(this.queens>=1 && this.queens<=8){
			queens--;
		}
	}
	
	public int popStack(int x) {
		if(x>0){
			int temp = stack[x]; 
			board[x][temp]=false;
			decQueens();
			if(temp<=7){
				return temp+1;
			}				
		}
		return -1;
		//printBoard();
	}
	
	public void pushStack(Integer index, Integer element) {
		this.stack[index] = element;
		board[index][element] = true;
		incQueens();
		//System.out.print("Placed Queen #"+queens+" at ("+index+","+element+")\n");
		//printBoard();
	}
	
	public void cleanBoard(){
		for(int i=0; i<8; i++){
			for(int j=0; j<8; j++){
				board[i][j] = false;
			}
		}
		this.clearStack();
		queens=0;
	}
	
	public void clearStack(){
		for(int i=0; i<8; i++){
			stack[i] = -1;
		}
	}
	public boolean isValid(int r, int c){
		//System.out.println("Checking validity for "+r+"-"+c);	
		
		int i = 0, j = 0;
		if (r <= 7 && r >= 0 && c <= 7 && c >= 0) {
			
			if(board[r][c]==true){
				return false;
			}
			
			// LEFT ROW
			i = r;
			for (j = 0; j < c; j++) {
				if (board[i][j] == true) {
					//System.out.println("Found attacking queen on LEFT - ROW");
					return false;
				} else {
					 //System.out.println("No attacking queen found on LEFT - ROW");
				}
			}

			// RIGHT ROW
			i = r;
			for (j = c + 1; j < 8; j++) {
				if (board[i][j] == true) {
					 //System.out.println("Found attacking queen on RIGHT - ROW");
					return false;
				} else {
					 //System.out.println("No attacking queen found on RIGHT - ROW");
				}
			}

			// TOP COLUMN
			j = c;
			for (i = 0; i < r; i++) {
				if (board[i][j] == true) {
					 //System.out.println("Found attacking queen on TOP - COLUMN");
					return false;
				} else {
					 //System.out.println("No attacking queen found on TOP - COLUMN");
				}
			}

			// BOTTOM COLUMN
			j = c;
			for (i = r + 1; i < 8; i++) {
				if (board[i][j] == true) {
					//System.out.println("Found attacking queen on BOTTOM - COLUMN");
					return false;
				} else {
					//System.out.println("No attacking queen found on BOTTOM - COLUMN");
				}
			}

			// BOTTOM - RIGHT - DIAGONAL
			for (i = r + 1, j = c + 1; (i < 8 && j < 8); i++, j++) {
				if (board[i][j] == true) {
					 //System.out.println("Found attacking queen on BOTTOM - RIGHT - DIAGONAL");
					return false;
				} else {
					 //System.out.println("No attacking queen found on BOTTOM - RIGHT - DIAGONAL");
				}
			}

			// UPPER - LEFT - DIAGONAL
			for (i = r - 1, j = c - 1; (i >= 0 && j >= 0); i--, j--) {
				if (board[i][j] == true) {
					 //System.out.println("Found attacking queen on UPPER - LEFT - DIAGONAL");
					return false;
				} else {
					 //System.out.println("No attacking queen found on UPPER - LEFT - DIAGONAL");
				}
			}

			// UPPER - RIGHT - DIAGONAL
			for (i = r - 1, j = c + 1; (i >= 0 && j < 8); i--, j++) {
				if (board[i][j] == true) {
					 //System.out.println("Found attacking queen on UPPER - RIGHT - DIAGONAL");
					return false;
				} else {
					 //System.out.println("No attacking queen found on UPPER - RIGHT - DIAGONAL");
				}
			}

			// BOTTOM - LEFT - DIAGONAL
			for (i = r + 1, j = c - 1; (i < 8 && j >= 0); i++, j--) {
				if (board[i][j] == true) {
					 //System.out.println("Found attacking queen on BOTTOM - LEFT - DIAGONAL");
					return false;
				} else {
					 //System.out.println("No attacking queen found on BOTTOM - LEFT - DIAGONAL");
				}
			}

			}// end of if branch
			//else	
			return true;
		}//end of isValid method


	public void printBoard(){
		System.out.println();
		for(int i=0; i<8; i++){
			for(int j=0; j<8; j++){
				if(board[i][j])
					System.out.print("1 ");
				else
					System.out.print("0 ");
			}
		System.out.println();	
		}
	}
	
	public void printStack(){
		String str = "[ ";
		for(int i=0; i<8; i++){
			str+=this.stack[i]+" ";			
		}
		str+="]";
		System.out.println(this.solutionCount+". "+str);
	}
}
